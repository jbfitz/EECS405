To build an Index:

1. Open the Index solution in MS Visual Studio 2013
2. Build and run the program
3. When prompted, enter either 'imdb' or 'dblp' to build a difference matrix and inverted list on the desired program.

To build a VGRAM Trie:

1. Open the VGRAM solution in MS Visual Studio 2013
2. Change the desired database to either imdb or dblp
3. Build and run the program, you will be prompted when the program is ready for a query

To build a Top-K Trie:

1. Open the TopK solution in MS Visual Studio 2013
2. Change the desired database to either imdb or dblp
3. Build and run the program, you will be prompted when the program is ready for a query